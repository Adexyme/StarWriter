export declare class AddEvtListener {
    static toElemChildren: (containerID: string, eventType: string, callbackFn: EventListener) => void;
    static toElem: (elemID: string, eventType: string, callbackFn: EventListener) => void;
}
