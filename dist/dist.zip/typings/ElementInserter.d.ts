export declare class ElementInserter {
    private cursorPosition;
    constructor(cursorPosition?: HTMLTextAreaElement);
    insertAtCursorPosition: (elem: string) => void;
}
