export declare const LoaderSpinner: {
    loader: any;
    body: any;
    md: string;
    ios: string;
    mode: any;
    cssClass: string;
    check: (mode: any) => void;
    open: (mode: any) => any;
    close: () => any;
    isOpen: () => any;
    ifOpened: (callback: any, close: any) => any;
    ifClosed: (callback: any, open: any) => any;
};
