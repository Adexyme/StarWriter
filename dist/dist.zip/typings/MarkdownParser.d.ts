export declare class MarkdownParser {
    static parse: (text: string) => string;
}
