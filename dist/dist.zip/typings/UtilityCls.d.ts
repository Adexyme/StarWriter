export declare class UtilityCls {
    static readonly inputElement = "iput";
    static readonly outputElement = "oput";
    static readonly markdownTagMenuholderID = "elemsHolderBtn";
    static readonly saveBTN = "saveBTN";
    static readonly newBTN = "newBTN";
    static readonly menuContainer = "#menuContainer";
    static readonly spinnerContainer = "#spinnerContainer";
    static readonly tagBtnContainer = "#elemsHolderBtn";
}
